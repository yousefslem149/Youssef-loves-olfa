# ألفة & يوسف 💗

موقع ثابت (HTML واحد). للنشر على GitHub Pages:

1. ارفع كل الملفات (index.html + مجلد assets + .nojekyll) على ريبو جديد.
2. Settings → Pages → Source: Deploy from a branch → main / (root).
3. الرابط هيكون: https://USERNAME.github.io/REPO/

تعديل: تاريخ البداية وكلمة السر في آخر index.html (START و PASSWORD).
