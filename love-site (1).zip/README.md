# رفع الموقع على GitHub Pages
1. ادخل github.com ← New repository ← اكتب اسم الريبو (مثلاً alfa-yousef) ← Public ← Create.
2. اضغط "uploading an existing file" وارفع كل محتويات المجلد (index.html + images + audio) ← Commit.
3. Settings ← Pages ← Source: Deploy from a branch ← Branch: main / (root) ← Save.
4. بعد دقيقة الرابط هيبقى: https://USERNAME.github.io/REPO-NAME/
الأغنية: حط الملف في مجلد audio باسم song.mp3 .
